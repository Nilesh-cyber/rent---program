Str = "1, 2, 3, 4, 5"

Tup = tuple(map(int,Str.split(', ')))
print("\nTuple = ", Tup)
print (type(Tup))