Num = int(input("\nEnter The Number : "))

Fact = 1 

for i in range(1,Num + 1 ):
	Fact = Fact * i 

print("\nFactors = ", Fact)