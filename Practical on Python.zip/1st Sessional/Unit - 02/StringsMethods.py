Str = "ritesh Gajjar"

print("\nString = ", Str)
print("\nStarts WIth r ?? = ", Str.startswith('r'))
print("\nStarts WIth r ?? = ", Str.endswith('r'))
print("\nString Upper = ", Str.upper())
print("\nString Lower = ", Str.lower())
print("\nString Title Case = ", Str.title())
print("\nString Capitalize = ", Str.capitalize())
print("\nString Count of r = ", Str.count('r'))
print("\nString Swapped Case = ", Str.swapcase())