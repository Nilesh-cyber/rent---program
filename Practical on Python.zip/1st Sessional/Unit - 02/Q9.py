Dict = {
	1 : "Ritesh",
	2 : "Kinjal",
	3 : "Hardik",
	4 : "Manav",
	5 : "Harry"
}

for i in Dict:
	print(" ", Dict.values() , " ")