Num = int(input("\nEnter The Number : "))

res = 0 
while (Num != 0):
	rem = Num % 10 
	res = (res * 10) + rem 
	Num = Num // 10 

print("\nReverse Value = ", res)