List = [2,4,6,8,10]

print("\nList = ", List)
print("\nList Append 12 = ", List.append(12))
print("\nList = ", List)


print("\nList 2 count = " ,List.count(2))

List2 = [12,14,16] 

print("\nList Extend = ", List.extend(List2))
print("\nList = ", List)

List.remove(12)
print("\nList Remove 12 = ", List)

POP = List.pop()
print(POP)