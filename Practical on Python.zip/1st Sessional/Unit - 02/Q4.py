Num1 = int(input("\nEnter The Number A : "))
Num2 = int(input("\nEnter The Number B : "))
Num3 = int(input("\nEnter The Number C : "))

print("\nValue A = ", Num1)
print("\nValue B = ", Num2)
print("\nValue C = ", Num3)

if(Num1 > Num2 and Num1 > Num3):
	print("\nValue A Is the Largest")
elif(Num2 > Num1 and Num2 > Num3):
	print("\nValue B Is the Largest")
elif(Num3 > Num1 and Num3 > Num2):
	print("\nValue C Is the Largest")