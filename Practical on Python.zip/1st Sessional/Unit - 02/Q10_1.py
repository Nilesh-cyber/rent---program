Dict = {
	1 : "Ritesh",
	2 : "Kinjal",
	3 : "Hardik",
	4 : "Manav",
	5 : "Harry"
}

print(Dict)


for i in Dict:
	Key = Dict.keys()
	del(Key) 

D2 = {
	6 : "Parmar Kinjal"
}

Dict.keys()
Dict.values()

print(Dict.update(D2))
print(Dict)