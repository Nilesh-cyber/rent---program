# list , list -> methods , del list element and store in new list
# list taken form user

Sum = 0 
for i in range(1,51):
	Sum += i

print("\nSum = ", Sum)