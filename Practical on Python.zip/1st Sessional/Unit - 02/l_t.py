l = [1, 2, 3, 4, 5]

print("\nList = ", l)
print("\nType of List = ", type(l))

Tup = tuple(l)
print("\nTuple to List = ", Tup)
print("\nType of Tuple to List = ", type(Tup))
