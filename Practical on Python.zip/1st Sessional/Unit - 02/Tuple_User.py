List = []

inr = 0 ; 
for i in range(0,5):
	n = int(input("\nEnter The Value : "))
	inr += 1
	List.insert(inr,n)


print("\nList = ", List)