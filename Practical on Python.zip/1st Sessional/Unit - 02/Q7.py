Tupe1 = (1,2,3,4,5)

print("\nTupple = ", Tupe1)

print("\n--------------------------------------\n")
print("\nMax value = ", max(Tupe1))
print("\nMin value = ", min(Tupe1))
print("\n--------------------------------------\n")
print("\nLength = ", len(Tupe1))
print("\n--------------------------------------\n")
Sum = 0 
for i in Tupe1:
	Sum += i

print("\nSum of Tuple's value = ", Sum)