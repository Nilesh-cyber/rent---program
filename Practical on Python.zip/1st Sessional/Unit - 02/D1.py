Dict = {
    "Name" : "Ritesh",
    "Age" : 21
}

print("\nDict = ", Dict)
print("\nDict = ", Dict.keys())
print("\nDict = ", Dict.values())

D2 = {
    "Address", "Naroda"
}
print("\nDict = ", Dict.update(D2))