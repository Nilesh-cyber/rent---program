Num1 = int(input("\nEnter The Number A : "))

print("\nValue A = ", Num1)

res = 0 
while(Num1 != 0) :
	rem = Num1 % 10 
	res = res + rem
	Num1 //= 10 

print("\nSum Of Digits = ", res)