n1 = 1510

print("\nNumber = ", n1)
print("Type = ", type(n1))

n2 = str(n1)
print("\nString Number = ", n1)
print("Type = ", type(n2))