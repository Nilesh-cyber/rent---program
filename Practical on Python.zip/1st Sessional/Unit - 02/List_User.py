List = [] 

for i in range(0,5):
	n = int(input("\nEnter The Value : "))
	List.append(n)


print("\nList = ", List)