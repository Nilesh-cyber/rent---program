Str = "GLS University"

print("\nString = ", Str)

Find = Str.find("Uni")
print("\nValue At = ", Find)