N1 = 5 
N2 = 5.5
N3 = 'Ritesh'

print('\nType of N1 = ', type(N1))
print('\nType of N2 = ', type(N2))
print('\nType of N3 = ', type(N3))