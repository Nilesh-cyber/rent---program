Str1 = str(input("\nEnter The String A : "))
Str2 = str(input("\nEnter The String B : "))

print("\nString A = ", Str1)
print("\nString B = ", Str2)

print("\nMerge String = ", (Str1 + Str2))