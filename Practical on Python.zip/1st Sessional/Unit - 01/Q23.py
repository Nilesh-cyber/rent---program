Str = "Hello World !! By le Python.."

print("\nStirng = ", Str)

Count_l = Str.count('l')
print("\nCount of L in String = ", Count_l)