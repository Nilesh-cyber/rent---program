Fruit = {
	1 : "Apple",
	2 : "Mango",
	3 : "Banana",
	4 : "Grapes",
	5 : "Kiwi"
}

print("\nOnly Keys = ", Fruit.keys())
print("\nOnly Values = ", Fruit.values())
