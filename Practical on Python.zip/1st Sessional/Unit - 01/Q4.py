# Create a Python program that will have one string variable =“Welcome to Python”.
# Perform following operations:
# • Print whole string
# • Print only first character of string
# • Print 3rd character to -1 character of string using slicing operator
# • Print string from 4thcharacter to the end of string using slicing operator
# • Print whole string 5 times using appropriate operator.

Str = "Welcome to Python"

print('[1] For Print Whole String..')
print('[2] For only 1st Character Of String..')
print('[3] For Print 3rd character to -1 character of string using slicing operator ..')
print('[4] For Print string from 4thcharacter to the end of string using slicing operator..')
print('[5] For Print whole string 5 times using appropriate operator...')

print() 

Ch = int(input("\nEnter Your Choice : "))


if(Ch == 1):
	print("\nString = ", Str)
elif(Ch == 2):
	print("\n1st Char. = ", Str[0])
elif(Ch == 3):
	print("\n3rd Char. to -1 = ", Str[3:-1])
elif(Ch == 4):
	print("\nStart from 4th = ", Str[4:])
elif(Ch == 5):
	print("\nString 5 Time = ")
	print(Str * 5)
else:
	print("\nInvalid Choice...") 