Str = "A B C || d e f"

print("\nStirng = ", Str)

Changed = Str.swapcase()
print("\nChanged Case = ", Changed)