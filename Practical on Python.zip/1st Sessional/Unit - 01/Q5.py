List = ["Navratri", "Diwali", "Holi", "Rakshabandhan", "Hanuman Jayanti", "Ram Jayanti"]

print('[1] For Print whole list..')
print('[2] For only 1st Element Of List..')
print('[3] For Prints elements starting from 2nd till 3rd..')
print('[4] For Prints elements starting from 2nd element till last..')
print('[5] For Print whole list 4 times using appropriate operator...')

print() 

Ch = int(input("\nEnter Your Choice : "))

if(Ch == 1):
	print("\nList = ", List)
elif(Ch == 2):
	print("\n1st Element = ", List[0])
elif(Ch == 3):
	print("\n2nd Till 3rd = ", List[2:3])
elif(Ch == 4):
	print("\nStart from 2nd = ", List[2:len(List)-1])
elif(Ch == 5):
	print("\nList 5 Time = ")
	print(List * 5)
else:
	print("\nInvalid Choice...") 