list = [2,4,6,8,10]

if(2 in list):
	print("\nYes Found..")
else:
	print("\nNot Found..")