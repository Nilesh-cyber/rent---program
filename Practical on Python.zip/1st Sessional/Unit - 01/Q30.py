Str = str(input("\nEnter The String : "))

print("\nString = ", Str)

print("\nEnds With h", Str.endswith("h"))
print("\nEnds With h", Str.startswith("r"))