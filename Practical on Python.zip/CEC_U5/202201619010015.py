import tkinter as RG
from tkinter import messagebox as Msg

def Display_Det():
    A = N1.get()
    B = N2.get()
    C = N3.get()
    D = N4.get()
    E = Click.get()
    DOB = N5.get()
    Msg.showinfo("Information Of User", f"Name = {A}\nMobile = {B}\nE-Mail = {C}\nGender = {D}\nHobbie = {E}\nDate of Birth = {DOB}")


win = RG.Tk()
win.title("Inquiry Form -- Ritesh Gajjar")
win.geometry("500x500")

N1 = RG.StringVar()
N2 = RG.IntVar()
N3 = RG.StringVar()
N4 = RG.StringVar()
N5 = RG.StringVar()

Name = RG.Label(win, text="Name : ")
Name.grid(row=0, column=0)
Name_User = RG.Entry(win, textvariable=N1)
Name_User.grid(row=0, column=2)

Mobile = RG.Label(win, text="Mobile : ")
Mobile.grid(row=1, column=0)
Mobile_User = RG.Entry(win, textvariable=N2)
Mobile_User.grid(row=1, column=2)

Email = RG.Label(win, text="E-Mail : ")
Email.grid(row=2, column=0)
Email_User = RG.Entry(win, textvariable=N3)
Email_User.grid(row=2, column=2)

Gen = RG.Label(win, text="Gender : ")
Gen.grid(row=3, column=0)
Male = RG.Radiobutton(win, text="Male", value="Male", variable=N4)
Male.grid(row=3, column=2)
Female = RG.Radiobutton(win, text="Female", value="Female", variable=N4)
Female.grid(row=3, column=3)

DOB_Label = RG.Label(win, text="Date of Birth (DD/MM/YYYY): ")
DOB_Label.grid(row=4, column=0)
DOB_User = RG.Entry(win, textvariable=N5)
DOB_User.grid(row=4, column=2)

List = ["Sports", "Reading", "Music", "Minecraft"]
Click = RG.StringVar()

Menu = RG.OptionMenu(win, Click, *List)
Menu.grid(row=5, column=0)

Bttn = RG.Button(win, text="Apply Form", command=Display_Det)
Bttn.grid(row=6, column=4)

win.mainloop()
