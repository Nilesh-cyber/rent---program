import tkinter as RG
from tkinter import messagebox as Msg


win = RG.Tk()
win.title("Question - 4")
win.geometry("500x500")

def Pass():
	Val = Age.get()

	if Val == "Male":
		Lbl = RG.Label(win, text = "Male...")
		Lbl.grid()
	else:
		Lbl = RG.Label(win, text = "Female...")
		Lbl.grid()

Age = RG.StringVar()

Radio1 = RG.Radiobutton(win, text = "Male", value = "Male", variable = Age)
Radio1.grid()
Radio2 = RG.Radiobutton(win, text = "Female", value = "Female", variable = Age)
Radio2.grid()

Quit = RG.Button(win, text = "Exit", command = win.quit)
Quit.grid()
Submt = RG.Button(win, text = "Show", command = Pass)
Submt.grid()

win.mainloop()