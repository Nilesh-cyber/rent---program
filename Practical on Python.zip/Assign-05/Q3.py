import tkinter as RG
from tkinter import messagebox as Msg 

win = RG.Tk()
win.title("Question - 3 ")
win.geometry("500x500")


def MyFn():
	a = N1.get()
	b = N2.get()
	c = N3.get()

	Arr = []
    
	if a:
		Arr.append("Burger")
	if b:
		Arr.append("Pizza")
	if c:
		Arr.append("Sandwitch")

	Msg.showinfo("Food ", f" {Arr} ")


N1 = RG.IntVar()
N2 = RG.IntVar()
N3 = RG.IntVar()
    

Title = RG.Label(win, text = "🍔 Chooose Your Favourite Food 🍕")
Title.grid(row = 0, column = 5, ipadx = 60)

Chk1 = RG.Checkbutton(win, text = "Burger 🍔", variable = N1)
Chk1.grid(row = 1, column = 2)
Chk2 = RG.Checkbutton(win, text = "Pizza 🍕", variable = N2)
Chk2.grid(row = 1, column = 4)
Chk3 = RG.Checkbutton(win, text = "Sandwitch 🥪", variable = N3)
Chk3.grid(row = 1, column = 3)


Apply = RG.Button(win, text = "Apply Food", command = MyFn)
Apply.grid()


win.mainloop()
