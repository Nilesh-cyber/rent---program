import tkinter as RG
from tkinter import messagebox as Msg

win = RG.Tk()
win.title("Question - 4")
win.geometry("500x500")

def Pass():
	Val = Age.get()

	if Val == "Age < 18":
		Msg.showinfo("Vote ?", "Noo, You're Not Eligible For Voting")
		Lbl = RG.Label(win, text = "You're Not Eligible For Voting...")
		Lbl.grid()
	else:
		Msg.showinfo("Vote ?", "Yes, You're Eligible For Voting")
		Lbl = RG.Label(win, text = "You're Eligible For Voting...")
		Lbl.grid()

Age = RG.StringVar()

Radio1 = RG.Radiobutton(win, text = "Age < 18", value = "Age < 18", variable = Age)
Radio1.grid()
Radio2 = RG.Radiobutton(win, text = "Age > 18", value = "Age > 18", variable = Age)
Radio2.grid()

Quit = RG.Button(win, text = "Exit", command = win.quit)
Quit.grid()
Submt = RG.Button(win, text = "Apply Age", command = Pass)
Submt.grid()

win.mainloop()