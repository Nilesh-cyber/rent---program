import tkinter as RG
from tkinter import messagebox as Msg
root = RG.Tk()

root.title(" Q1 Program ")
root.geometry("600x600")


def MyFn():
    Msg.showinfo("Yeah", "Hello, By Ritesh Gajjar")
 

User_Button = RG.Button(root, text = "See Message", command = MyFn, bd = 6, activebackground = "yellow",  font = "Consolas", bg = "lime", highlightcolor = "blue")
User_Button.grid(padx = 50, pady = 50)

root.mainloop()
