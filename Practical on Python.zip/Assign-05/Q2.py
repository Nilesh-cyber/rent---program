import tkinter as RG
from tkinter import messagebox as Msg 

win = RG.Tk()
win.geometry("500x500")
win.title("Q2 --> Ritesh Gajjar")


def Check():
	Value = Sel.get()
	Msg.showinfo("Selected Language ", f"Language = {Value}")


Sel = RG.StringVar()


RadioBt1 = RG.Radiobutton(win, text = "Python", value = "Python", variable = Sel)
RadioBt1.grid(row = 0 , column = 1)

RadioBt2 = RG.Radiobutton(win, text = "C++", value = "C++", variable = Sel)
RadioBt2.grid(row = 1, column = 1)

RadioBt3 = RG.Radiobutton(win, text = "Perl", value = "Perl", variable = Sel)
RadioBt3.grid(row = 2 , column = 1)

RadioBt4 = RG.Radiobutton(win, text = "C", value = "C", variable = Sel)
RadioBt4.grid(row = 3 , column = 1)

RadioBt5 = RG.Radiobutton(win, text = "Java", value = "Java", variable = Sel)
RadioBt5.grid(row = 4 , column = 1)




Button = RG.Button(win, text = "Apply Form", command = Check)
Button.grid(row = 7, column = 2)


win.mainloop()
