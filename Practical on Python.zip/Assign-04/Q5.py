def Fn(Val):
    try:
        if(Val > 0):
            print("\nGood...")
        else:
            raise ValueError
    except ValueError:
        print("\nInvalid Data....")


Data = int(input("\nEnter The Data : "))
Fn(Data)
