def Fn():
    while True:
        try:
            Data = input("\nEnter The Data : ")
            
            Return_Val = int(Data)
            return Return_Val

        except ValueError:
            print("\nValue error...\nEnter Numeric Data.. Please 😭😭")

Value = Fn()
print("\nValue = ", Value)