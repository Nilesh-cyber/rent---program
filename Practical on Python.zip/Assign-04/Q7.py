def Fn(Val):
    try:
        if(Val > 0):
            print("\nPositive Data...")
        else:
            raise ValueError
    except ValueError:
        print("\nNegative Data....")


Data = int(input("\nEnter The Data : "))
Fn(Data)