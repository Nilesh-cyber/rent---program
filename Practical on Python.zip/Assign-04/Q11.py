class Bank_Acc():
    def __init__(self,Num, Bal, Date_Open_Acc, Customer_Name):
        self.Num = Num
        self.Bal = Bal
        self.Date_Open_Acc = Date_Open_Acc
        self.Customer_Name = Customer_Name

    def Deopsit(self, Ammount):
        print("--------------- Customer [",self.Customer_Name ,"] ------------------")
        print("Old Balance = ", self.Bal)
        self.Bal = self.Bal + Ammount
        print("\nUpdated Balance = ", self.Bal)

    def Withdraw(self, Ammount_With):
        print("\n--------------- Withdraw Customer [", self.Customer_Name, "] ------------------")
        print("Old Balance = ", self.Bal)
        self.Bal = self.Bal - Ammount_With
        print("\nUpdated Balance = ", self.Bal)


    def Check_Bal(self):
        print("\n--------------- Balance Of [", self.Customer_Name, "] ------------------")
        print(" Balance = ", self.Bal)

Ob1 = Bank_Acc(123, 35000, "13-10-2024", "Ritesh")
Ob1.Deopsit(5000)
Ob1.Withdraw(15000)
Ob1.Check_Bal()
print("------------------------------------------------------")
