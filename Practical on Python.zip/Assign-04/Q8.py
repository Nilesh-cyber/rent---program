class Data():
    def __init__(self,Name, Age):
        self.Name = Name
        self.Age = Age

    def Fn(self):
        print("\nName = ", self.Name)
        print("\nAge = ", self.Age)


OB1 = Data("Ritesh",20)
OB2 = Data("Devansh",21)

OB1.Fn()
OB2.Fn()