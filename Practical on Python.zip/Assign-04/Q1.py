def Check_Age():
    try:
        Age = input("\nEnter The Age : ")
        X = int(Age)

    except ValueError:
        print("\nValue error...")

Check_Age()