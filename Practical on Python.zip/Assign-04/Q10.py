class Employee():
    def __init__(self, Empid, Ename, ESal, EDept):
        self.Empid = Empid
        self.Ename = Ename
        self.ESal = ESal
        self.EDept = EDept
    def Cal_Emp_Sal(self,Hour_Work):
        print("\n\n\n\n--------------------- Calculates The Salary --------------------------")
        print("\nSalary of [", self.Ename, "] = ", self.ESal)
        if(Hour_Work > 50):
            print("Person Do Overtime...")
            Per_Hour = 500
            Update_Sal = Hour_Work * Per_Hour
            self.ESal = Update_Sal + self.ESal
            print("\nActual Salary = ", self.ESal)
        else:
            pass
    def Print_Emp_Dept(self):
        print("----------------------------------------------------------------")
        print("\nEmployee Id = ", self.Empid)
        print("\nEmployee Name = ", self.Ename)
        print("\nEmployee Salary = ", self.ESal)
        print("\nEmployee Department = ", self.EDept)

    def Emp_Assign_Depart(self):
        print("\n\nUpdated Details = ")
        self.EDept = "Re-search"

Ob1 = Employee(15, "Ritesh", 50000, "Manager")
Ob2 = Employee(16, "Manav", 40000, "CR")
Ob3 = Employee(17, "Omm", 67000, "HR")
Ob4 = Employee(18, "Sudhanshu", 10000, "Sales")

Ob1.Cal_Emp_Sal(55)
Ob2.Cal_Emp_Sal(30)
Ob3.Cal_Emp_Sal(10)
Ob4.Cal_Emp_Sal(28)


Ob1.Print_Emp_Dept()
Ob2.Print_Emp_Dept()
Ob3.Print_Emp_Dept()
Ob4.Print_Emp_Dept()

Ob4.Emp_Assign_Depart()
Ob4.Print_Emp_Dept()
