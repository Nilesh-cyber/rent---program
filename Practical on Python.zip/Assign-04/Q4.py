N1 = int(input("\nEnter The Value Of N1 : "))
N2 = int(input("\nEnter The Value Of N2 : "))

try:
    if(N2 == 0):
        raise Exception("N2 Value Is Zero..")
    else:
        Ans = N1 / N2 
        print("\nAnswer = ", Ans)
        
except Exception as RG:
    print("\nException Error = ", RG)
    
