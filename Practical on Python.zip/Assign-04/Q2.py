N1 = int(input("\nEnter The Value Of N1 : "))
N2 = int(input("\nEnter The Value Of N2 : "))

try:
    if(N2 == 0):
        raise Exception("N2 Value Is Zero..")
    else:
        print("\nValue N1 = ", N1)
        print("\nValue N2 = ", N2)
        
except Exception as RG:
    print("\nException Error = ", RG)
    
