class Data():
    def Fn(self,List):
        print("\nList = ", List)

Arr = [2,4,6,8,10]

Ob = Data()
Ob.Fn(Arr)