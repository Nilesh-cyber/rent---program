Name = str(input("\nEnter The Name : "))

try:
    if(Name != "Ritesh"):
        raise Exception("Invalid Name..")
    else:
        print("\nWelcome, Mr.", Name)

except Exception as RG:
    print("\nException = ", RG)

finally:
    print("\nBye...")