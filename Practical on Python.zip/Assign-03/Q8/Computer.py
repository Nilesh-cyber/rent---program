def Mouse():
    print("\nReadgear Mouse is best....")
    
def Keyboard():
    print("\nReadgear Keyboatd is best....")
    
def CPU():
    print("\nGaming CPU is best....")