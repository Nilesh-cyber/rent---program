import Computer as RG

print(RG.Mouse())
print(RG.Keyboard())
print(RG.CPU())