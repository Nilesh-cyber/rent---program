from .Fruit import Apple,Banana,Orange
from .Veg import Tomato,Potato