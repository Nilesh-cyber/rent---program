def Apple():
    print("\nApple running...")

def Banana():
    print("\nBanana running...")


def Orange():
    print("\nOrange running...")