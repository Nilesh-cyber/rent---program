def Potato(x):
    print("\nPotato running..." * x)

def Tomato(x):
    print("\nTomato running..." * x)