import Lunch as RG

RG.Apple()
RG.Banana()
RG.Orange()
RG.Potato(2)
RG.Tomato(4)