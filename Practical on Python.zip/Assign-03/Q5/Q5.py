import random as RG

Ans = RG.random()
print("\nRandom Value = ", Ans)