def Add(a,b):
    ans = a + b 
    return ans

def Sub(a,b):
    ans = a - b 
    return ans

def Mul(a,b):
    ans = a * b 
    return ans

def Div(a,b):
    ans = a / b 
    return ans
