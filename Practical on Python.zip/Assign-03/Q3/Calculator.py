from Calc import Add,Sub,Mul,Div

a = int(input("\nEnter The Value Of A : "))
b = int(input("\nEnter The Value Of B : "))

Adding = Add(a,b)
print("\nSum = ", Adding)

Subing = Sub(a,b)
print("\nSub = ", Subing)

Muling = Mul(a,b)
print("\nMul = ", Muling)

Diving = Div(a,b)
print("\nDiv = ", Diving)
