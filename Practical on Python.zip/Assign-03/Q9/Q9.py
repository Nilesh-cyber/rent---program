def Out(a,b):
    print("\nOut Function Called...") 
    Sum = a + b 
   
    def In(Sum):
        print("\nIn Function Called...") 
        Sum += 5 
        return Sum

    Res = In(Sum)
    return Res
    
    
a = int(input("\nEnter Value Of A : "))
b = int(input("\nEnter Value Of B : "))
Ans = Out(a,b)
print("\nAnswer = ", Ans)