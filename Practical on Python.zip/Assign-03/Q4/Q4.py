import random as RG

List1 = ["Ritesh", "Dhurvisha", "Hardik", "Manav"]

print("\nWhole List = ", List1)

Random_Val = RG.choice(List1)
print("\nRandom Value in List1 = ", Random_Val)
