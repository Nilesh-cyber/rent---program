def Sum(a, b):
    if a > b:
        return 0
    else:
        return a + Sum(a + 1, b)


result = Sum(0, 10)
print("\nSum =", result)
