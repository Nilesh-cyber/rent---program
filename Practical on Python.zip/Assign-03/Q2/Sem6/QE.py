def DT():
    print("\nData Enginnering running....")

def Drupal():
    print("\nDrupal running....")