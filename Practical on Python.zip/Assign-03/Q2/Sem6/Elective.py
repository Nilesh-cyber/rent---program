def ML():
    print("\nMachine Learning running....")