from .Core import Python, AI, SE, Infosec
from .QE import Drupal, DT
from .Elective import ML