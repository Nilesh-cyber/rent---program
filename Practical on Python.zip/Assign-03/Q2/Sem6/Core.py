def Python():
    print("\nPytohn is programming language...")

def Infosec():
    print("\nInfosec is security...")

def SE():
    print("\nSoftware Engineering running....")

def AI():
    print("\nAI running....")