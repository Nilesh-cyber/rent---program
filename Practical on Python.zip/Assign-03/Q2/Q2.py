import Sem6 as RG

print(RG.Python())
print(RG.AI())
print(RG.Infosec())
print(RG.SE())