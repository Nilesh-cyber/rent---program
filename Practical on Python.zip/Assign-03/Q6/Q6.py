def Calculation(a,b):
    A1 = a + b
    A2 = a - b
    
    return A1,A2


A = int(input("\nEnter The Value Of A : "))
B = int(input("\nEnter The Value Of B : "))
Ans1,Ans2 = Calculation(A,B)
print("\nSum. = ", Ans1)
print("\nSub. = ", Ans2)