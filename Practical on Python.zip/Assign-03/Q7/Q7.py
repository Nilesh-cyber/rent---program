def Emp(Name,Salary = 300000):
    Month_Salary = Salary / 12
    print("\nName = ", Name)
    print("\nMonthly Salary = ", Month_Salary)
    
    def Company():
        print("\nCompnay Name = TCS 🌹")
    
    Company()
    

Name = str(input("\nEnter Your Name : "))
Salary = float(input("\nEnter Your Package : "))


Emp(Name,Salary)