from Collage import Admin
from Collage import Student
from Collage.Data import Gift as RG
from Collage.Data.File import Hello as Ritesh

A, B, C, D = Student.Result()

print("\nEroll-Number = ", A)
print("\nName = ", B)   
print("\nTotal = ", C)
print("\nPR = ", D)

Pass = Admin.Result_Cal(D)
print("\n ", Pass)

E = RG.Giftt()
print("\nGift was = ", E)

G = Ritesh.Hel()
print("\nMessage Was = ", G)