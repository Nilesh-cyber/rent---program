def Fibbo(*val):
    N1, N2 = 0, 1 
    
    Term1 = val[0]
    Term2 = val[1]
     
    print("\n  ", N1, "  ", N2, end= '  ')
    
    i = 1
    while range(i < Term1 + 1):
        N3 = N1 + N2 
        print(N3, end='   ')
        N1 = N2 
        N2 = N3 
        N3 = N1 + N2 
        i += 1
        
        
        
        
    # dusra baccha :)
    N1, N2 = 0, 1 
    print("\n  ", N1, "  ", N2, end= '  ')
    
    i = 1
    while range(i < Term2 + 1):
        N3 = N1 + N2 
        print(N3, end='   ')
        N1 = N2 
        N2 = N3 
        N3 = N1 + N2 
        i += 1
    

Fibbo(5,3)     