def Result_Cal(PR):
    if(PR < 65):
        return "Try Next Year Brother"
    else:
        return "You're Eligeble"