def Giftt():
    return "Ritesh Is The Best Programmer..." 