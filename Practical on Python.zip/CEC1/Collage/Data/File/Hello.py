def Hel():
    return ("\nHello, Ritesh Gajjar")