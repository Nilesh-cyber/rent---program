def Result():
    Enroll = (input("\nEnter Your Enroll-Roll Number : "))
    Name = str(input("\nEnter Your Name : "))
    Sub1 = int(input("\nEnter Your Marks Of Pract. PhP : "))
    Sub2 = int(input("\nEnter Your Marks Of Pract. Python : "))
    Sub3 = int(input("\nEnter Your Marks Of Pract. Multimedia : "))
    Sub4 = int(input("\nEnter Your Marks Of Thoery. PhP : "))
    Sub5 = int(input("\nEnter Your Marks Of Thoery. Python : "))
    Sub6 = int(input("\nEnter Your Marks Of Thoery. C.G. : "))
    Sub7 = int(input("\nEnter Your Marks Of Thoery. M.M. : "))
    Sub8 = int(input("\nEnter Your Marks Of Thoery. O.O.A.D. : "))
    
    Total = (Sub1) + (Sub2) + (Sub3) + (Sub4) + (Sub5) + (Sub6) + (Sub7) + (Sub8)
    PR = (Total / 8)
    
    return Enroll, Name, Total, PR